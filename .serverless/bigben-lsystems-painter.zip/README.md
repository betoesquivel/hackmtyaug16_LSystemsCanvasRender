# hackmtyaug16_LSystemsRenderToS3
Lambda function that receives an item in DynamoDB representing an LSystem's params, and the LSystem's g_command string and outputs a png image into an S3 bucket.
